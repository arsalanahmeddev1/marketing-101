<header class="inner-header">
    <div class="container-fluid">
        <div class="row align-items-center justify-content-between ">
            <div class="col-md-6">
                <div class="d-flex align-items-center gap-2 sm-justify-content-center">
                    <div class="logo">
                        <a class="mb-0" href='./'>Marketing 101</a>
                    </div>
                    <h5 class="f-arial f-13 mb-0">SF bay area</h5>
                </div>
            </div>
            <div class="col-md-6 text-end d-flex justify-content-end sm-justify-content-center sm-mt-10">
                <h5 class="d-flex justify-content-center  f-13 text-black f-arial mb-0 header-right-area">[ logged in as
                    example@example.com ] <a class="ms-1 px-2" href="">[ log out ]</a>
                </h5>
            </div>
        </div>
    </div>
</header>